jQuery(document).ready(function($) {
    // Define the pickup locations for each agent
    
     var agentLocations = {
        'cbd': {
            'philadelphia_house': 'PHILADELPHIA HOUSE, Next To Afya Centre: Pickup Mtaani, 3RD Floor, Wing A',
            'star_mall': 'STAR MALL, TOM MBOYA: 3RD Floor, C14, Pickup Mtaani'
        },
        'mombasa_rd': {
            'south_c': 'South C, Shopping Center: Ellys Drycleaners Next to GMAT Supermarket',
            'south_b': 'South B, Sana Sana: Delight Beauty Shop, Next to Sana Sana Butchery',
            'imara_daima': 'Imara Daima Junction Near Muimara: Mwaniki Clothing Store Next to Sokomart Milk ATM',
            'syokimau_1': 'Syokimau, Gateway Mall: The Lighthouse Acquarium Opposite Family Bank 2ND Floor',
            'syokimau_2': 'Syokimau Luqman Petrol Station: Ecobella Tyers First Floor',
            'syokimau_3': 'Syokimau Katani Road: Rakels Bakery, Ground Floor Moose Business Centre',
            'mlolongo': 'Mlolongo: Nomadic Brands Behind Olympic Petrol Station',
            'kitengela': 'Kitengela Rubis Petrol Station Opposite Jupiter House: Suds & Duds Drycleaners Oppossite Former Midas Hotel',
            'greatwall_gardens_2': 'Greatwall Gardens 2: Shop A1, The Corner Hub',
        },
        'langata_rd': {
            'madaraka': 'Madaraka Shopping Center: Makeos Auto Spares Behind Koogo Holding Building',
            'one_stop_plaza': 'One Stop Plaza Next To T-Mall: Chamkat Enterprises 1ST Floor',
            'nairobi_west': 'Nairobi West Shopping Center: Samken Electronics Oppossite Hotel Rio',
            'langata': 'Langata Oppossite Ola Petrol Station: Poravim Business Complex, Trend M Salon Next To Swala & Tala',
            'kiserian': 'Kiserian Oppossite Total Petrol Station: Xtreme Media, below Liqour Well Lounge',
            'rongai_1': 'Rongai Tuskys Stage Next to Clean Shelf: Xtreme Media',
            'rongai_2': 'Rongai behind Quickmart, former Tuamini: Xtreme Media',
            'rongai_3': 'Rongai Maasai Lodge Stage: Xtreme Media opposite Think Twice',
            'karen_galleria': 'Karen Galleria Kolani Village: Meditas Pharmacy oppossite Rubis Petrol Station',
        },
         'waiyaki_way': {
            'westlands': 'Westlands Commercial Center opposite Kenrail Towers: Shop No. 10, Fits on Time',
            'kileleshwa': 'Kileleshwa along Kandara Road: Trend De Barbers next to Viva Lounge & Tunic Kitchen',
            'loresho': 'Loresho Shopping Center: Boutiqi Disney Clothier opposite JD Suppermarket',
            'kangemi': 'Kangemi opposite Total Petrol Station: Flexnett Cyber, Room 32, Hot Point Bazaar',
            'uthiru': 'Uthiru Shopping Center: Karsam Gas Point opposite Kabira Ecomatt Supermarket',
            '87_kinoo': '87 Kinoo Stage: The Shoe Rack, The Jamaican Plaza',
            'kinoo': 'Kinoo Stage opposite Jacmil Supermarket: Aigle Pharmacy next to Equity ATM',
            'kikuyu': 'Kikuyu Next to Seniors Driving School: Prime Eye Care',
        },
         'kiambu_rd': {
            'thindigua': 'Thindigua opposite Quickmart: Feruzi Towers, Cush Kids, 3RD Floor',
            'kiambu_town': 'Kiambu Town opposite Kiambu Police Station: Kellah Beauty 2.0 Nail Spa, Roseview 1ST Floor',
            'kirigiti': 'Kirigiti Frapu Complex: Playpause Accessorize Shop A22, 1st Floor'
        },
         'limuru_rd': {
            'ruaka_arcade': 'Ruaka Arcade opposite Cleanshelf Supermarket: All Qiet Dynasty Cosmetics, Shop No. 20',
            'ruaka_business_park': 'Ruaka Business Park opposite Getrudes: Terminal Center Shop No. C12',
            'village_market': 'Village Market New Wing: Halfpriced Books',
            'two_rivers_mall': 'Two Rivers Mall Floor above Art Cafe Bakery Stand: Tazama Gallery next to Samsung Customer Care'
        },
         'jogoo_rd': {
            'buruburu': 'Buruburu Phase 2 behind C0-Operative Bank: Hope Salon, Shop c7, Buruburu Complex',
            'umoja_market': 'Umoja Market next to Co-Operative Bank: Exioni Drycleaners',
            'umoja_1': 'Umoja 1 Mtindwa Stage: Tippy Toes M Entrance',
            'umoja_kwa_chief': 'Umoja Kwa Chief Stage: Erico Cyber opposite Eden True Food & Kitchen',
            'umoja_innercore': 'Umoja Innercore along Moi Drive: Exxioni Drycleaners next to Oloiboni Hotel',
            'komarock': 'Komarock near K-Mall opposite Stage ya Phase 4: Endless Fancy Wear, Green shop with bags',
            'donholm_1': 'Donholm Kisumu Ndogo: Sirkal Matiyo Cyber opposite PEFA Church',
            'donholm_2': 'Donholm opposite Greenspan: Arcade Link Playstation & Movie Shop',
            'fedha_stage': 'Fedha Stage: Vyrian Salon opposite Front Quickmart Exit',
            'nyayo_embakasi': 'Nyayo Embakasi Total Petrol Station: The Link Cyber',
            'Utawala_1': 'Utawala Benedicta near Lexo: Sheks Baby Wear',
            'utawala_2': 'Utawala Shooters Stage: Streamlink Entertainment above Flame Grill',
            'choka': 'Choka: Poa Dealz Investments next to Astrid Villas',
            'ruai': 'Ruai Gatwic Business Center: Vision Tech Cyber, C18, opposite Fast Smart Supermarket',
            
        },
         'thika_rd': {
            'ruaraka': 'Ruaraka Allsops: Qwanza Laundry Services opposite Qwetu Living & Sell Petrol Station',
            'roasters': 'Roasters next to Akai Plaza Parking: Winks Electricals on The Green Safaricom Painted Building',
            'marurui': 'Marurui Stage: Duka Moja Shop, third shop on the left entering Marurui',
            'kasarani': 'Kasarani opposite Kasarani Police Station: Janpharm Pharmaceuticals ICIPE Road opposite Regional Center for Mapping',
            'kasarani_seasons': 'Kasarani Seasons off Seasons Road: Pinky Rosy Salon opposite Jirani Minimart',
            'kasarani_sunton': 'Kasarani Sunton Kwa Mafuta: Venue Beauty & Cosmetics opposite Cocacola Depot',
            'kasarani_2': 'Kasarani Stage Ya Maternity: Contour Business Center, Lebran Mitumba, Shop C4',
            'gumba_estate': 'Gumba Estate: Hairkut Experts, Gumba Estate Stage',
            'trm_drive': 'TRM Drive Boon Apartments: Sister s Laundry Ground Floor',
            'roysambu_1': 'Roysambu Lumumba Drive: Tesoro Trends, Shop 410 opposite Red Plate Restaurant',
            'roysambu_2': 'Roysambu Flyover: DMPOLIN Entertainment at Roysambu Footbridge(on the side heading to Thika)',
            'roysambu_3': 'Roysambu Kamiti Road opposite Quickmart: Cush Kids Mtaani',
            'zimmerman': 'Zimmerman behind Deliverance Church: Megatex Fresh Products',
            'usiu': 'USIU next to Chimek House: Everything Mystique',
            'kahawa_wendani_1': 'Kahawa Wendani former Becks next to the Footbridge; Everythin Mystique',
            'kahawa_wendani_2': 'Kahawa Wendani opposite Wendani Juniour & Alijam House: Victory Cerals & Shop',
            'kenyatta_university': 'Kenyatta University Old Library Building: Younique Creations',
            'ruiru_bypass': 'Ruiru Bypass Kamakis along Eastern Bypass: Hampton Heights opposite Greenspot Kwanza Kids Baby Shop, Shop 03',
            'ruiru_ndani': 'Ruiru Ndani opposite Bushgate Towers: The Changes, Rowini House, Ground Floor',
            'juja_stage': 'Juja Stage next to Taxi Stage: Jimngash Phones & Accessories next to Neolite Pharmacy',
            'juja': 'Juja near JKUAT Main Gate: Spykes Gaming',
            
        },
         'ngong_rd': {
            'upperhill': 'Upperhill along Bagati Road opposite NHIF: Safaricom Painted Barbershop, Capital Hill Polisce Station',
            'adams': 'Adams next to Greenhouse: Soko Safi Shopping Mall Harriet Botanicals',
            'jamhuri': 'Jamhuri Shopping Center: Shop Direct next to Former Buyrite Supermarket',
            'kilimani': 'Kilimani Yaya Center: Homecare & Hardware LTD, Ground Floor',
            'lavington': 'Lavington Mall: Halfpriced Books, 1ST Floor next to Post Office',
            'wanyee_rd': 'Wanyee Road: Great By Choice Enterprise at Suna Estate Stage',
            'ngong_race_course': 'Ngong Race Course: Gesmat next to Kalabash Lounge near Be Petrol Station',
            'karen_1': 'Karen Heri Plaza next to Shell near DP Residence: The Pastry Palace',
            'karen_2': 'Karen Shopping Center opposite Sell Petrol Station: Shop 1ST Shop on the left, Ground Floor',
            'karen_3': 'Karen Hardy: Ace Outfits, Luken Business Center',
            'riruta': 'Riruta PC Kinyanjui: DH Entertainment , Technical Training Institute Stage',
            'satellite': 'Satellite Marathon Stage: DMBS Smartphone Clinic',
            'ngong_stage': 'Ngong Stage at Ilade Oil: The Yard Movie Shop at Ilade Oil Petrol Station',
            
            
            
        },
    };

    // Listen for changes in the Pickup Agent field
    $('#pickup_mtaani_area').change(function() {
        var pickupAgentValue = $(this).val();
        var pickupLocationField = $('#pickup_mtaani_agent');
        
        //alert(pickupAgentValue);

        //Update the options of the Pickup Agent field based on the Pickup Area selection
        if (pickupAgentValue in agentLocations) {
            
            var locations = agentLocations[pickupAgentValue];
           
            pickupLocationField.empty();
            $.each(locations, function(key, value) {
                pickupLocationField.append($('<option></option>').attr('value', key).text(value));
            });
            pickupLocationField.closest('.form-row').show();
        } else {
            pickupLocationField.empty();
            pickupLocationField.closest('.form-row').hide();
        }
    });
    
    
    
    function toggleFieldsVisibility() {
    var pickupOption = $('#pickup_mtaani_option').val();
    var deliveryField = $('#delivery_address');
    var pickupAreaField = $('#pickup_mtaani_area');
    var pickupAgentField = $('#pickup_mtaani_agent');

    // Hide delivery field by default
    deliveryField.hide();

    // Show/hide fields based on pickup option
    if (pickupOption === 'home_delivery') {
      pickupAreaField.hide();
      pickupAgentField.hide();
      deliveryField.show();
    } else {
      pickupAreaField.show();
      pickupAgentField.show();
    }
  }

  // Call the function on page load
  toggleFieldsVisibility();

  // Call the function whenever the pickup option changes
  $('#pickup_mtaani_option').change(function() {
    toggleFieldsVisibility();
  });
  
  
});

