<?php

// In order to prevent direct access to the plugin
defined('ABSPATH') or die("No access please!");
// Plugin header- notifies wordpress of the existence of the plugin
/* Plugin Name: Pickup Mtaani Shipping by Archer Analytics 

* Plugin URI: https://archer.glx.co.ke/

* Description: A Woocommerce plugin to integrate Pickup Mtaani delivery services to your online shop. 

* Version: 1.0.2

* Author: Archer Analytics

* License: GPL v2 or later
* License URI:       https://www.gnu.org/licenses/gpl-2.0.html

* WC requires at least: 4.7

* WC tested up to: 6.4.2

*/

 add_action( 'woocommerce_shipping_init', 'pickup_mtaani_shipping_init' );
 
 function pickup_mtaani_shipping_init(){
     
     if(! class_exists( 'ARCHER_PICKUP_MTAANI_SHIPPING')){
         
         class ARCHER_PICKUP_MTAANI_SHIPPING extends WC_Shipping_Method {
             
             /**
				 * Constructor for your shipping class
				 *
				 * @access public
				 * @return void
				 */
             
             
             public function __construct() {
                $this->id  = 'archer_pickup_mtaani_shipping'; // Id for your shipping method. Should be uunique.
				$this->method_title = __( 'Pickup Mtaani Delivery' );  // Title shown in admin
				$this->method_description = __( 'A Woocommerce plugin to integrate Pickup Mtaani delivery services to your online shop.' ); //      Description shown in admin

				$this->enabled = "yes"; // This can be added as an setting but for this example its forced enabled
				$this->title = "Pickup Mtaani Delivery"; // This can be added as an setting but for this example its forced.

				$this->init();
             }
             
             /**
				 * Init your settings
				 *
				 * @access public
				 * @return void
				 */
             
             public function init(){
                // Load the settings API
				$this->init_form_fields(); // This is part of the settings API. Override the method to add your own settings
				$this->init_settings(); // This is part of the settings API. Loads settings you previously init.
				$this->remove_fields(); //This function removes the irrelevant address related fields in the checkout form

				// Save settings in admin if you have any defined
				add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
            }
            
            /**
				 * calculate_shipping function.
				 *
				 * @access public
				 * @param array $package
				 * @return void
				 */
            
            
            public function calculate_shipping( $package = array() ){
                
                //get the shipping fee from the admin settings
                
                $settings = get_option('woocommerce_archer_pickup_mtaani_shipping_settings');
                
                $shipping_fee ;
               
                if (isset($settings['shipping_fee'])){
                    
                    $shipping_fee = $settings['shipping_fee'];
                    
                }
                
                $rate = array(
						 'id' => $this->id,
                         'label' => $this->title,
                         'cost' => $shipping_fee,
					);

                    
                //Register the rate
                $this->add_rate( $rate );
            }
            
            //form fields at the admin setting panel
            function init_form_fields() {



                 $this->form_fields = array(

                 'enabled' => array(
        
                            'title'   => __( 'Enable', 'woocommerce' ),
                
                            'type'    => 'checkbox',
                
                            'label'   => __( 'Enable Pickup Mtaani Delivery Plugin' ),
                
                            'default' => 'yes'

                          ),
                  'remove_fields' => array(
        
                            'title'   => __( 'Remove Default Address Fields', 'woocommerce' ),
                
                            'type'    => 'checkbox',
                
                            'label'   => __( 'Allowing this will remove the fields State/County, Street Adress, Town/City and Company.' ),
                
                            'default' => 'no'

                          ),        

                 'shipping_fee' => array(

                            'title'       => __( 'Shipping Fee', 'woocommerce' ),
                
                            'type'        => 'number',
                
                            'description' => __( 'The amount you charge fro Pickup Mtaani Deliveries', 'woocommerce' ),
                
                            'default'     => __( ' ', 'woocommerce' ),
                
                            'desc_tip'    => true,

                         ),

                   

                   

                     
			

	             	

	

		                 );

               }
               
            
            //this function removes the irrelevant address related fields from the checkout form


            function remove_fields(){
                    
                            $fields_to_remove = array(
                            'billing_company',
                            'billing_address_1',
                            'billing_address_2',
                            'billing_city',
                            'billing_state',
                            'billing_postcode'
                        );
                            
                    
                    $settings = get_option('woocommerce_archer_pickup_mtaani_shipping_settings'); 
                    
                    // Check if the "remove_fields" field exists and its value is true
                    if (isset($settings['remove_fields']) && $settings['remove_fields'] == 'yes') {
                        
                      add_filter('woocommerce_checkout_fields', function($fields) use ($fields_to_remove) {
                        foreach ($fields_to_remove as $field_key) {
                            if (isset($fields['billing'][$field_key])) {
                                unset($fields['billing'][$field_key]);
                            }
                        }
                        return $fields;
                     });
                    }
                    
                }

           //end of removing irrelevant address fields on checkout for
           
          

            
               
               
           
                 
                
             }
             
             
             
         }
         
     }
//importing the pickup_mtaani.js file
function pickup_mtaani_enque_script() {
    // Enqueue the pickup.js file
    wp_enqueue_script('pickup-mtaani-script', plugin_dir_url(__FILE__) . 'pickup_mtaani(3).js', array('jquery'), '1.0', true);
}

add_action('wp_enqueue_scripts', 'pickup_mtaani_enque_script');


//overriding irrelevant billing fields
function pickup_mtaani_override_default_billing_fields($fields) {
    
    unset($fields['billing']['billing_address_1']);
    unset($fields['billing']['billing_city']);
    unset($fields['billing']['billing_state']);
    unset($fields['billing']['billing_postcode']);

    return $fields;
}
add_filter('woocommerce_checkout_fields', 'pickup_mtaani_override_default_billing_fields');


 // Set the default value of the country field to Kenya
function pickup_mtaani_kenya_default_country_value($fields) {
                
    $fields['billing']['billing_country']['default'] = 'KE'; // Set 'KE' as the default country code
               
     return $fields;
      }
             
add_filter('woocommerce_checkout_fields', 'pickup_mtaani_kenya_default_country_value');

//adding pickup mtaani fields on the checkout form

//pickup mtaani option field
function pickup_mtaani_option( $checkout ) {
   woocommerce_form_field( 
    'pickup_mtaani_option', 
    array(
        'type'          => 'select',
        'required'      => true,
        'class'         => array( 'pickup_mtaani_option', 'form-row-wide' ),
        'label'         => 'Pickup Mtaani Option',
        'label_class'   => 'pickup_mtaani_option-label',
        'options'       => array(
            'agent' => 'Pickup Mtaani Agent',
            'home_delivery' => 'Home or Office Delivery',
        )
    ), 
    $checkout->get_value( 'pickup_mtaani_option' ) 
  );
}

add_action( 'woocommerce_after_checkout_billing_form', 'pickup_mtaani_option' );


//office or home delivery address
function pickup_mtaani_delivery_address_field( $checkout ) {
  woocommerce_form_field( 
    'delivery_address', 
    array(
        'type'          => 'text',
        'required'      => true,
        'class'         => array( 'delivery-address', 'form-row-wide' ),
        'label'         => 'Home or Office Address',
        'label_class'   => 'delivery-address-label',
    ), 
    $checkout->get_value( 'delivery_address' ) 
  );
}

add_action( 'woocommerce_after_checkout_billing_form', 'pickup_mtaani_delivery_address_field' );


//pickup area or major road field
function pickup_mtaani_area( $checkout ) {
    
     $agents = array(
        'cbd' => array(
            'name' => __('CBD', 'woocommerce'),
        ),
        
        'mombasa_rd' => array(
            'name' => __('Mombasa Road', 'woocommerce'),
        ),
        
        'langata_rd' => array(
            'name' => __('Langata Road', 'woocommerce'),
        ),
        
        'waiyaki_way' => array(
            'name' => __('Waiyaki Way', 'woocommerce'),
        ),
        
        'kiambu_rd' => array(
            'name' => __('Kiambu Road', 'woocommerce'),
        ),
        
        'limuru_rd' => array(
            'name' => __('Limuru Road', 'woocommerce'),
        ),
        
        'jogoo_rd' => array(
            'name' => __('Jogoo Road', 'woocommerce'),
        ),
        
        'thika_rd' => array(
            'name' => __('Thika Road', 'woocommerce'),
        ),
        
        'ngong_rd' => array(
            'name' => __('Ngong Road', 'woocommerce'),
        ),
  
 
    );
    
     $pickup_agent_options = array();
    foreach ($agents as $agent_key => $agent) {
        $pickup_agent_options[$agent_key] = $agent['name'];
    }
    
    
   woocommerce_form_field( 
    'pickup_mtaani_area', 
    array(
        'type'          => 'select',
        'required'      => true,
        'class'         => array( 'pickup_mtaani_area', 'form-row-wide' ),
        'label'         => 'Pickup Mtaani Area/Road',
        'label_class'   => 'pickup-mtaani-area-label',
        'options'       => $pickup_agent_options
    ), 
    $checkout->get_value( 'pickup_mtaani_area' ) 
  );
}

add_action( 'woocommerce_after_checkout_billing_form', 'pickup_mtaani_area' );

//pickup mtaani agent field
function pickup_mtaani_agent( $checkout ) {
    
     $pickup_locations =  array(
                'philadelphia_house' => __('PHILADELPHIA HOUSE, Next To Afya Centre: Pickup Mtaani, 3RD Floor, Wing A', 'woocommerce'),
                'star_mall' => __('STAR MALL, TOM MBOYA: 3RD Floor, C14, Pickup Mtaani', 'woocommerce'),
            );
    
   woocommerce_form_field( 
    'pickup_mtaani_agent', 
    array(
        'type'          => 'select',
        'required'      => true,
        'class'         => array( 'pickup_mtaani_agent', 'form-row-wide' ),
        'label'         => 'Pickup Mtaani Agent',
        'label_class'   => 'pickup-mtaani-agent-label',
        'options'       => $pickup_locations
    ), 
    $checkout->get_value( 'pickup_mtaani_agent' ) 
  );
}

add_action( 'woocommerce_after_checkout_billing_form', 'pickup_mtaani_agent' );


//saving value of custom fields to order meta

function pickup_mtaani_checkout_field_update_order_meta( $order ) {
        
    $pickup_mtaani_areas = array(
        'cbd' => 'CBD',
        
        'mombasa_rd' => 'Mombasa Road',
        
        'langata_rd' =>'Langata Road',
        
        'waiyaki_way' => 'Waiyaki Way',
        
        'kiambu_rd' => 'Kiambu Road',
        
        'limuru_rd' => 'Limuru Road',
        
        'jogoo_rd' => 'Jogoo Road',
        
        'thika_rd' => 'Thika Road', 
        
        'ngong_rd' => 'Ngong Road',
  
    );
    
    $pickup_mtaani_agent_locations = array(
   
        'philadelphia_house' => 'PHILADELPHIA HOUSE, Next To Afya Centre: Pickup Mtaani, 3RD Floor, Wing A',
        'star_mall' => 'STAR MALL, TOM MBOYA: 3RD Floor, C14, Pickup Mtaani',
        'south_c' => 'South C, Shopping Center: Ellys Drycleaners Next to GMAT Supermarket',
        'south_b' => 'South B, Sana Sana: Delight Beauty Shop, Next to Sana Sana Butchery',
        'imara_daima' => 'Imara Daima Junction Near Muimara: Mwaniki Clothing Store Next to Sokomart Milk ATM',
        'syokimau_1' => 'Syokimau, Gateway Mall: The Lighthouse Acquarium Opposite Family Bank 2ND Floor',
        'syokimau_2' => 'Syokimau Luqman Petrol Station: Ecobella Tyers First Floor',
        'syokimau_3' => 'Syokimau Katani Road: Rakels Bakery, Ground Floor Moose Business Centre',
        'mlolongo' => 'Mlolongo: Nomadic Brands Behind Olympic Petrol Station',
        'kitengela' => 'Kitengela Rubis Petrol Station Opposite Jupiter House: Suds & Duds Drycleaners Oppossite Former Midas Hotel',
        'greatwall_gardens_2' => 'Greatwall Gardens 2: Shop A1, The Corner Hub',
        'madaraka' => 'Madaraka Shopping Center: Makeos Auto Spares Behind Koogo Holding Building',
        'one_stop_plaza' => 'One Stop Plaza Next To T-Mall: Chamkat Enterprises 1ST Floor',
        'nairobi_west' => 'Nairobi West Shopping Center: Samken Electronics Oppossite Hotel Rio',
        'langata' => 'Langata Oppossite Ola Petrol Station: Poravim Business Complex, Trend M Salon Next To Swala & Tala',
        'kiserian' => 'Kiserian Oppossite Total Petrol Station: Xtreme Media, below Liqour Well Lounge',
        'rongai_1' => 'Rongai Tuskys Stage Next to Clean Shelf: Xtreme Media',
        'rongai_2' => 'Rongai behind Quickmart, former Tuamini: Xtreme Media',
        'rongai_3' => 'Rongai Maasai Lodge Stage: Xtreme Media opposite Think Twice',
        'karen_galleria' => 'Karen Galleria Kolani Village: Meditas Pharmacy oppossite Rubis Petrol Station',
        'westlands' => 'Westlands Commercial Center opposite Kenrail Towers: Shop No. 10, Fits on Time',
        'kileleshwa' => 'Kileleshwa along Kandara Road: Trend De Barbers next to Viva Lounge & Tunic Kitchen',
        'loresho' => 'Loresho Shopping Center: Boutiqi Disney Clothier opposite JD Suppermarket',
        'kangemi' => 'Kangemi opposite Total Petrol Station: Flexnett Cyber, Room 32, Hot Point Bazaar',
        'uthiru' => 'Uthiru Shopping Center: Karsam Gas Point opposite Kabira Ecomatt Supermarket',
        '87_kinoo' => '87 Kinoo Stage: The Shoe Rack, The Jamaican Plaza',
        'kinoo' => 'Kinoo Stage opposite Jacmil Supermarket: Aigle Pharmacy next to Equity ATM',
        'kikuyu' => 'Kikuyu Next to Seniors Driving School: Prime Eye Care',
        'thindigua' => 'Thindigua opposite Quickmart: Feruzi Towers, Cush Kids, 3RD Floor',
        'kiambu_town' => 'Kiambu Town opposite Kiambu Police Station: Kellah Beauty 2.0 Nail Spa, Roseview 1ST Floor',
        'kirigiti' => 'Kirigiti Frapu Complex: Playpause Accessorize Shop A22, 1st Floor',
        'ruaka_arcade' => 'Ruaka Arcade opposite Cleanshelf Supermarket: All Qiet Dynasty Cosmetics, Shop No. 20',
        'ruaka_business_park' => 'Ruaka Business Park opposite Getrudes: Terminal Center Shop No. C12',
        'village_market' => 'Village Market New Wing: Halfpriced Books',
        'two_rivers_mall' => 'Two Rivers Mall Floor above Art Cafe Bakery Stand: Tazama Gallery next to Samsung Customer Care',
        'buruburu' => 'Buruburu Phase 2 behind C0-Operative Bank: Hope Salon, Shop c7, Buruburu Complex',
        'umoja_market' => 'Umoja Market next to Co-Operative Bank: Exioni Drycleaners',
        'umoja_1' => 'Umoja 1 Mtindwa Stage: Tippy Toes M Entrance',
        'umoja_kwa_chief' => 'Umoja Kwa Chief Stage: Erico Cyber opposite Eden True Food & Kitchen',
        'umoja_innercore' => 'Umoja Innercore along Moi Drive: Exxioni Drycleaners next to Oloiboni Hotel',
        'komarock' => 'Komarock near K-Mall opposite Stage ya Phase 4: Endless Fancy Wear, Green shop with bags',
        'donholm_1' => 'Donholm Kisumu Ndogo: Sirkal Matiyo Cyber opposite PEFA Church',
        'donholm_2' => 'Donholm opposite Greenspan: Arcade Link Playstation & Movie Shop',
        'fedha_stage' => 'Fedha Stage: Vyrian Salon opposite Front Quickmart Exit',
        'nyayo_embakasi' => 'Nyayo Embakasi Total Petrol Station: The Link Cyber',
        'Utawala_1' => 'Utawala Benedicta near Lexo: Sheks Baby Wear',
        'utawala_2' => 'Utawala Shooters Stage: Streamlink Entertainment above Flame Grill',
        'choka' => 'Choka: Poa Dealz Investments next to Astrid Villas',
        'ruai' => 'Ruai Gatwic Business Center: Vision Tech Cyber, C18, opposite Fast Smart Supermarket',
        'ruaraka' => 'Ruaraka Allsops: Qwanza Laundry Services opposite Qwetu Living & Sell Petrol Station',
        'roasters' => 'Roasters next to Akai Plaza Parking: Winks Electricals on The Green Safaricom Painted Building',
        'marurui' => 'Marurui Stage: Duka Moja Shop, third shop on the left entering Marurui',
        'kasarani' => 'Kasarani opposite Kasarani Police Station: Janpharm Pharmaceuticals ICIPE Road opposite Regional Center for Mapping',
        'kasarani_seasons' => 'Kasarani Seasons off Seasons Road: Pinky Rosy Salon opposite Jirani Minimart',
        'kasarani_sunton' => 'Kasarani Sunton Kwa Mafuta: Venue Beauty & Cosmetics opposite Cocacola Depot',
        'kasarani_2' => 'Kasarani Stage Ya Maternity: Contour Business Center, Lebran Mitumba, Shop C4',
        'gumba_estate' => 'Gumba Estate: Hairkut Experts, Gumba Estate Stage',
        'trm_drive' => 'TRM Drive Boon Apartments: Sister s Laundry Ground Floor',
        'roysambu_1' => 'Roysambu Lumumba Drive: Tesoro Trends, Shop 410 opposite Red Plate Restaurant',
        'roysambu_2' => 'Roysambu Flyover: DMPOLIN Entertainment at Roysambu Footbridge(on the side heading to Thika)',
        'roysambu_3' => 'Roysambu Kamiti Road opposite Quickmart: Cush Kids Mtaani',
        'zimmerman' => 'Zimmerman behind Deliverance Church: Megatex Fresh Products',
        'usiu' => 'USIU next to Chimek House: Everything Mystique',
        'kahawa_wendani_1' => 'Kahawa Wendani former Becks next to the Footbridge; Everythin Mystique',
        'kahawa_wendani_2' => 'Kahawa Wendani opposite Wendani Juniour & Alijam House: Victory Cerals & Shop',
        'kenyatta_university' => 'Kenyatta University Old Library Building: Younique Creations',
        'ruiru_bypass' => 'Ruiru Bypass Kamakis along Eastern Bypass: Hampton Heights opposite Greenspot Kwanza Kids Baby Shop, Shop 03',
        'ruiru_ndani' => 'Ruiru Ndani opposite Bushgate Towers: The Changes, Rowini House, Ground Floor',
        'juja_stage' => 'Juja Stage next to Taxi Stage: Jimngash Phones & Accessories next to Neolite Pharmacy',
        'juja' => 'Juja near JKUAT Main Gate: Spykes Gaming',
        'upperhill' => 'Upperhill along Bagati Road opposite NHIF: Safaricom Painted Barbershop, Capital Hill Polisce Station',
        'adams' => 'Adams next to Greenhouse: Soko Safi Shopping Mall Harriet Botanicals',
        'jamhuri' => 'Jamhuri Shopping Center: Shop Direct next to Former Buyrite Supermarket',
        'kilimani' => 'Kilimani Yaya Center: Homecare & Hardware LTD, Ground Floor',
        'lavington' => 'Lavington Mall: Halfpriced Books, 1ST Floor next to Post Office',
        'wanyee_rd' => 'Wanyee Road: Great By Choice Enterprise at Suna Estate Stage',
        'ngong_race_course' => 'Ngong Race Course: Gesmat next to Kalabash Lounge near Be Petrol Station',
        'karen_1' => 'Karen Heri Plaza next to Shell near DP Residence: The Pastry Palace',
        'karen_2' => 'Karen near Nairobi Academy: Salon Haircut Point',
        'karen_3' => 'Karen Tangaza University opposite Nakumatt Crossroads: Healthy Harvest Limited'
    
     );

    
    
      //incase home/office address is selected
      if ( isset( $_POST['delivery_address'] ) && ! empty( $_POST[ 'delivery_address' ] ) ) {
            $order->update_meta_data( '_delivery_address', sanitize_text_field( $_POST[ 'delivery_address' ] ) );

            // Update user data
            if ( $order->get_user_id() > 0 ) {
                update_user_meta( $order->get_user_id(), 'delivery_address', true );
            }
        }
        
        //incase pickup mtaani agent is selected
        if ( isset( $_POST[ 'pickup_mtaani_area' ] ) && ! empty( $_POST[ 'pickup_mtaani_area' ] ) ) {

            // Sanitize the input
            $pickup_mtaani_area = htmlspecialchars( $_POST['pickup_mtaani_area'] );

            // Validate the input against the predefined array
            if ( array_key_exists( $pickup_mtaani_area, $pickup_mtaani_areas ) ) {
                // Valid input, proceed
                $pickup_mtaani_area_value = $pickup_mtaani_areas[$pickup_mtaani_area];

                $order->update_meta_data( '_pickup_mtaani_area', sanitize_text_field( $pickup_mtaani_area_value ) );

                // Update user data
                if ( $order->get_user_id() > 0 ) {
                    update_user_meta( $order->get_user_id(), $pickup_mtaani_area_value, true );
                }
                
                 if ( isset( $_POST[ 'pickup_mtaani_agent' ] ) && ! empty( $_POST[ 'pickup_mtaani_agent' ] ) ) {
                     
                     $pickup_agent = htmlspecialchars($_POST[ 'pickup_mtaani_agent' ]);

                     if ( array_key_exists( $pickup_agent, $pickup_mtaani_agent_locations ) ) {

                     $pickup_agent_value = $pickup_mtaani_agent_locations[$pickup_agent];
                     
                     $order->update_meta_data( '_pickup_mtaani_agent', sanitize_text_field( $pickup_agent_value ) );
    
                      // Update user data
                      if ( $order->get_user_id() > 0 ) {
                        update_user_meta( $order->get_user_id(), $pickup_agent_value, true );
                        
                       }  
                       
                     }else{

                        // Invalid input,
                      echo "Invalid pickup_agent value.";

                     }
                
               }

                
            } else {
                // Invalid input,
                echo "Invalid pickup_mtaani_area value.";
            }         
            
        }
         
}

add_action( 'woocommerce_checkout_create_order', 'pickup_mtaani_checkout_field_update_order_meta' );



//displaying custom field values to the order details page

function pickup_mtaani_checkout_field_display_admin_order_meta( $order ){
    $value = $order->get_meta( '_contactmethod' );
    $delivery_address = $order->get_meta('_delivery_address');
    $pickup_mtaani_area = $order->get_meta('_pickup_mtaani_area');
    $pickup_mtaani_agent = $order->get_meta('_pickup_mtaani_agent');

    if ( ! empty($value) ) {
        echo '<p><strong>'.__('Pickup Area/Road&#63;').':</strong> ' . esc_html( $value ) . '</p>';
    }
    
    if ( ! empty($delivery_address) ) {
        echo '<p><strong>'.__('Home/Office Adress: ').':</strong> ' . esc_html( $delivery_address ) . '</p>';
    }
    
    if ( ! empty($pickup_mtaani_area) ) {
        echo '<p><strong>'.__('Pickup Area/Road: ').':</strong> ' . esc_html( $pickup_mtaani_area ) . '</p>';
    }
    
    if ( ! empty($pickup_mtaani_agent) ) {
        echo '<p><strong>'.__('Pickup Mtaani Agent: ').':</strong> ' . esc_html( $pickup_mtaani_agent ) . '</p>';
    }
    
    
}
add_action( 'woocommerce_admin_order_data_after_billing_address', 'pickup_mtaani_checkout_field_display_admin_order_meta', 10, 1 );
     
 //adding our custom ARCHER_PICKUP_MTAANI_SHIPPING class to list of Woocommerce Methods
 function pickup_mtaani_method( $methods ){
     $methods['archer_pickup_mtaani_shipping'] = 'ARCHER_PICKUP_MTAANI_SHIPPING';
     
     return $methods;
 }
 
add_filter('woocommerce_shipping_methods', 'pickup_mtaani_method');












?>