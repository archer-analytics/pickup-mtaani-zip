=== Pickup MtaaniWoocommerce Plugin ===
Contributors: archeranalyticske
Donate link: https://archer.glx.co.ke
Tags: pickup-mtaani, kenya, mpesa
Requires at least: 4.7
Tested up to: 6.4.2
Stable tag: 1.0.2
Requires PHP: 7.2
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Let your customers use Pickup Mtaani for deliveries.

== Description ==

A Woocommerce plugin that integrates Pickup Mtaani to your online shop.

How it works:
* You add the plugin to your Woccommerce shop
* Customers can select Pickup Mtaani as a delivery option during checkout
* Customers pick their area and the closest pickup points
* This information is displayed along with other order information after customer places the order
* You take the package to your nearest Pickup Mtaani agent and address it to the pickup point the customer specified
* Customers gets their package within the same day within Nairobi


== Frequently Asked Questions ==

= Who pays for the delivery? =

When you install the plugin, you have the option to let the customers pay for the delivery, in this case, you set the delivery fee
depending on the current rates of Pickup Mtaani and that will be added to the price of the order at checkout. If you choose to pay for the deliveries
the delivery fee is not added at checkout.

= What are the delivery fee rates? =

The shopowner sets the delivery fee themselves depending on where their shop is located and the rates of Ppickup Mtaani at the time.


== Screenshots ==

== Changelog ==

== Upgrade Notice ==
